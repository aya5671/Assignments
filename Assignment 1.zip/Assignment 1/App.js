const {Add,Sub,Mult,Div} = require("./Math.js");

console.log(Add(6, 3));
console.log(Sub(6, 3)); 
console.log(Mult(6, 3));
console.log(Div(6, 3));
