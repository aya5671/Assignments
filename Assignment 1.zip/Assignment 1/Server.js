//#region FS Module (Sync & Async)
const fs = require('fs');

// SYNC
try{
    const data =fs.readFileSync("./Info.txt", "utf-8");

    fs.writeFileSync("./Summary.txt", "The file was read successfully and it contains "+ data.length + " characters.", "utf-8");
    console.log( data);
}
catch (error) {
    console.error("Error");
}

//ASYNC
fs.readFile("./Info.txt", "utf-8", (err, data) => {
    if (err) {
        console.error("Error reading file:", err);
        return;
    }else{
        fs.writeFileSync("./Summary.txt", "The file was read successfully and it contains "+ data.length + " characters.", "utf-8");
    console.log(data);
    }
});
//#endregion

//#region HTTP Module
const http = require('http');

const Server = http.createServer((req, res) => {
    if (req.url === '/home') {
        res.writeHead(200, { 'Content-Type': 'text/txt' });
        res.end('Welcome to the Home Page');
    } else if (req.url === '/about') {
        const text = fs.readFileSync('./Info.txt', 'utf-8');
        res.writeHead(200, { 'Content-Type': 'text/txt' });
        res.end(text);
    } else if (req.url === '/data') {
        const raw = fs.readFileSync("./data.json", "utf-8");
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(raw);                           
    } else {
        res.writeHead(404, { 'Content-Type': 'text/txt' });
        res.end('Page Not Found');
    }
});
Server.listen(3000, () => {
    console.log('Server is running....');
});
//#endregion

//#region Callback Hell to Promises

//Callback Hell
fs.readFile('./Steps/Step1.txt', 'utf-8', (err, data) => {
    console.log(data);
    fs.readFile('./Steps/Step2.txt', 'utf-8', (err, data) => {
        console.log(data);
        fs.readFile('./Steps/Step3.txt', 'utf-8', (err, data) => {
            console.log(data);
        });
    });  
});

//Promises
  const fsPromises = require('fs').promises;
fsPromises.readFile('./Steps/Step1.txt', 'utf-8')
    .then((data) => {
        console.log(data);
        return fsPromises.readFile('./Steps/Step2.txt', 'utf-8');
    })
    .then((data) => {
        console.log(data);
        return fsPromises.readFile('./Steps/Step3.txt', 'utf-8');
    })
    .then((data) => {
        console.log(data);
    })
    .catch((error) => {
        console.error("Error");
    })

//Async/Await 
const readAllSteps =  (path) => {
    return new Promise((resolve, reject) => {
        fs.readFile(path, 'utf-8', (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        });
    });
}

const read = async() => {
    try {
        const step1 = await fsPromises.readFile('./Steps/Step1.txt', 'utf-8');
        console.log(step1);
        const step2 = await fsPromises.readFile('./Steps/Step2.txt', 'utf-8');
        console.log(step2);
        const step3 = await fsPromises.readFile('./Steps/Step3.txt', 'utf-8');
        console.log(step3);
    } catch (error) {
        console.error("Error");
    }
}

read();

//#endregion

//#region Basic Express App

const express = require('express');
const app = express();

app.use(express.json());
app.get('/', (req, res) => {
    res.end('Hello from Express!');
});
app.get('/users', (req, res) => {
    const text = fs.readFileSync('./Users.json', 'utf-8');
    res.json(JSON.parse(text));
});
app.post('/users', (req, res) => {
    const newUser = req.body;
    const text = fs.readFileSync('./Users.json', 'utf-8');
    const users = JSON.parse(text);
    users.push(newUser);
    fs.writeFileSync('./Users.json', JSON.stringify(users, null, 2), 'utf-8');
    res.status(201).json(newUser);
});

app.listen(3000, () => {
    console.log('Express server...');
});

//#endregion

