exports.Add =(num1 , num2)=>{
    return num1 + num2;
}

exports.Mult =(num1 , num2)=>{
    return num1 * num2;
}

exports.Div =(num1 , num2)=>{
    return num1 / num2;
}

exports.Sub =(num1 , num2)=>{
    return num1 - num2;
}